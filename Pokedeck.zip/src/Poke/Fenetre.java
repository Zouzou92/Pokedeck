package Poke;

import java.awt.*;
import java.awt.event.*;
import java.awt.Component;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRootPane;
import javax.swing.JComponent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import java.net.URL;
import javax.imageio.ImageIO;


import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.*;
import javax.json.stream;

import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;

import java.util.Scanner;
// VOIR CE LIEN : https://openclassrooms.com/courses/apprenez-a-programmer-en-java/positionner-des-boutons

// Je veux positionner 4 boutons : Ajouter une carte, Supprimer une carte,
// Modifier une carte, Afficher le contenu du deck (liste d�roulante) et Rechercher une carte
// Ensuite, afficher le contenu en dessous

public class Fenetre extends JFrame implements ActionListener {
	private JPanel pan = new JPanel();
	private static JButton removeCard = new JButton("Remove a card");
	private static JComboBox cardList = new JComboBox();
	private static JLabel cardImage = new JLabel();
	private JTextField choice = new JTextField();
	
	
	private static String setpokeID;
	
	final JComponent[] inputs = new JComponent[] {
			new JLabel("ID"),choice
	};
	
	
	
	// deck is an array, it contains every pokemon card added to the deck (in json)
	//private JComboBox selectCard = new JComboBox(deck);
	
	
	
	public Fenetre() {
		this.setTitle("Pok�deck");
		this.setSize(1280,720);
		this.setLocationRelativeTo(null); // centre la fen�tre au lancement
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		

		JButton addCard = new JButton("Add a new card");
		addCard.addActionListener(this);
		removeCard.addActionListener(this);
		
		cardList.addActionListener(this);
		
		pan.add(addCard);
		pan.add(removeCard);
		pan.add(cardList);
		pan.add(cardImage);
		
		this.setContentPane(pan);
		this.setVisible(true);
		
		
		
	}
	
	@Override
	public void actionPerformed(ActionEvent evt) {
		Object src = evt.getSource();
		System.out.println(evt.getActionCommand().toString());
		// If Add a new card is clicked
		if(evt.getActionCommand().toString().equals("Add a new card")) {
			String result = JOptionPane.showInputDialog("Choose a card");
			if(result!=null) {
				try {
					sendGet(result);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//System.out.println(result);
			}
			else {
				System.out.println("Ajout annul�");
			}
			
		}
		// If Remove a card is clicked
		else if(evt.getActionCommand().toString().equals("Remove a card")) {
			cardList.removeItem(cardList.getSelectedItem());
		}
		else {
			System.out.println(cardList.getSelectedItem().toString());
			//JSONObject img = new JSONObject(cardList.getSelectedItem());

			//System.out.println(img.getJSONObject("card").get("imageUrl"));
		}
	}
	
	public String getID() {
		return pokeID;
	}
	
	// The next class is used to call the api from the trading card game data base
	
		private void sendGet(String pokemon) throws Exception {
			

			String url = "https://api.pokemontcg.io/v1/cards/" + pokemon;

			URL obj = new URL(url);
			HttpURLConnection con = (HttpURLConnection) obj.openConnection();

			// optional default is GET
			con.setRequestMethod("GET");

			//add request header
			con.setRequestProperty("User-Agent", USER_AGENT);

			int responseCode = con.getResponseCode();
			System.out.println("\nSending 'GET' request to URL : " + url);
			System.out.println("Response Code : " + responseCode);

			BufferedReader in = new BufferedReader(
			        new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();

			//print result
			System.out.println(response.toString());
			
			DeckManagement myDeck = new DeckWriter("test.txt");
			
			myDeck.writeDeck(response.toString());

			JSONObject parser = new JSONObject(response.toString());

			cardList.addItem(parser.getJSONObject("card").get("name"));
			/*
			Image image = null;
			try {
				URL img = new URL(parser.getJSONObject("card").get("imageUrl").toString());
				image = ImageIO.read(img);
			} catch (Exception e) {
				e.printStackTrace();
			}
			JFrame frame = new JFrame();
			frame.setSize(300, 300);
			JLabel label = new JLabel(new ImageIcon(image));
			frame.add(label);
			frame.setVisible(true);*/
		}
		
		
		private final String USER_AGENT = "Mozilla/5.0";

		public static void main(String[] args) throws Exception {
			
			
			final Fenetre fenetre = new Fenetre();
			
			//Scanner sc = new Scanner();
			
			//sc.useDelimiter("&");
			
			//DeckManagement rdDeck = new DeckReader("test.txt");
			
			//System.out.println(rdDeck.readDeck());
			
			//String pokemon = "xy7-54"; // Set as the wanted pokemon
			
			//Test http = new Test();
			
			//fenetre.sendGet("xy7-54");
			
			System.out.println("Testing 1 - Send Http GET request");
			
			//removeCard.addActionListener(this);
			//fenetre.sendGet(pokeID);

		}
	
	
}

/*
 Cr�er une classe qui impl�mente Actionlestener, qui va recevoir le clic
 cette classe a fenetre en argument et fait le sendget
 et faire un try catch au niveau de l'exception*/
