package Poke;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class DeckReader extends DeckManagement implements DeckFile {
	
	public DeckReader(String src) {
		super(src);
	}
	
	public String readDeck(){
		try {
			String tmp = "";
			super.deckReader = new FileReader(super.deck);
			while(super.deckReader.read()!=-1) {
				tmp += super.deckReader.read();
			}
			return tmp;
		} catch (FileNotFoundException e) {
			System.out.println("The file can not be read as the file doesn't exists");
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}