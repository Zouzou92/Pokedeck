package Poke;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;

abstract class DeckManagement implements DeckFile {
	
	protected File deck; // La propri�t� qui contient le chemin vers le fichier
	protected FileReader deckReader;
	protected FileWriter deckWriter;
	
	public DeckManagement(String src) {
		// The constructor initialise the File property with the path contained in src
		this.deck = new File(src);
	}
	
	public void openDeck() {
		// Si le fichier existe, on renvoie true, sinon on renvoie false
		if(this.deck.exists()) {
			System.out.println("The file exists");
		}
		else {
			System.out.println("The file doesn't exist");
		}
	}

	//abstract String readDeck();
	
	abstract void writeDeck(String cardInfo);
}
