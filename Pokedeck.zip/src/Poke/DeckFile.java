package Poke;

public interface DeckFile{
	public void openDeck();
	public String readDeck();
	public void writeDeck(String cardInfo);
}
