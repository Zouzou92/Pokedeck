package Poke;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import java.io.BufferedWriter;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;


public class DeckWriter extends DeckManagement implements DeckFile {
	public DeckWriter(String src) {
		super(src);
	}
	
	public void writeDeck(String cardInfo){
		try{
			cardInfo += "&";
			Files.write(Paths.get(super.deck.getPath()), cardInfo.getBytes(), StandardOpenOption.APPEND);
			/*super.deckWriter = new FileWriter(super.deck,true);
			BufferedWriter bw = new BufferedWriter(super.deckWriter);
			PrintWriter out = new PrintWriter(bw);
			out.print(cardInfo);*/
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
